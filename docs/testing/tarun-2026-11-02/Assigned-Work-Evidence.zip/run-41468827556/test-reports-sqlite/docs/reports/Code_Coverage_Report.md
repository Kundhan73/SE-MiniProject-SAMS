# Code coverage report

Generated from actual execution at 2026-11-02T15:10:27.554797+00:00. Database: SQLite.

Statements covered: **764/764 (100.00%)**. Target: 80%.

Measured application modules: accounts, attendance, audit, core, courses, notifications and reports. Migrations, management commands and framework internals are excluded. This percentage does not measure frontend JavaScript, deployment configuration, security assurance, or user acceptance. Raw evidence: `coverage.xml`; CI also uploads the HTML coverage report.
