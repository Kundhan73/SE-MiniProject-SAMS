# Branch coverage report

Generated from actual execution at 2026-11-02T15:10:23.649990+00:00. Database: PostgreSQL.

Branches covered: **167/170 (98.24%)**. Target: 70%.

Branches are measured by coverage.py with branch measurement enabled. Each observed control-flow destination counts as a branch. Source: `coverage.xml`.
