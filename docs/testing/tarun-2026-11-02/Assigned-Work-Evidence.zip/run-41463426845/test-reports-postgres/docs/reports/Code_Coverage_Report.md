# Code coverage report

Generated from actual execution at 2026-11-02T14:36:32.485088+00:00. Database: PostgreSQL.

Statements covered: **764/764 (100.00%)**. Target: 80%.

Measured application modules: accounts, attendance, audit, core, courses, notifications and reports. Migrations, management commands and framework internals are excluded. This percentage does not measure frontend JavaScript, deployment configuration, security assurance, or user acceptance. Raw evidence: `coverage.xml`; CI also uploads the HTML coverage report.
