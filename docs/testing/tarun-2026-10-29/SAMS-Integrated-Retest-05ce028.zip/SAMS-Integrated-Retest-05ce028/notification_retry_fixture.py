import os
import sys
import json
sys.path.insert(0, '/app')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sams.settings')
import django
django.setup()
from accounts.models import User
from notifications.models import Notification
from notifications.tasks import deliver_email

key = 'validation-smtp-retry-05ce028'
action = sys.argv[1]
if action == 'create':
    item, created = Notification.objects.get_or_create(key=key, defaults={
        'user': User.objects.get(username='STU001'),
        'message': 'SMTP-RETRY-05ce028: synthetic retry/exhaustion/recovery validation.'})
    if created:
        deliver_email.apply_async(args=[item.pk], queue='validation-failures')
else:
    item = Notification.objects.get(key=key)
    if action == 'recover':
        deliver_email.apply_async(args=[item.pk], queue='validation-failures')
item.refresh_from_db()
print(json.dumps({'key':item.key,'notification_id':item.pk,'email_sent':item.email_sent,'email_attempts':item.email_attempts,'email_error':item.email_error,'in_app_message_retained':bool(item.message)},indent=2))
