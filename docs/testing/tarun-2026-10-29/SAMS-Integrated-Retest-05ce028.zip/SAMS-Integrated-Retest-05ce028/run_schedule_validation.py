from datetime import datetime, timezone
from pathlib import Path
import os
import subprocess
import time

root = Path(__file__).resolve().parent
out = root.parent / 'outputs/SAMS-Integrated-Retest-05ce028'
docker = r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
os.environ['PATH'] = str(Path(docker).parent) + os.pathsep + os.environ['PATH']
name = 'sams-schedule-validation-2'
command = [docker, 'compose', '-p', 'sams-tarun-05ce028', 'run', '-d', '--no-deps', '--name', name, '--env', 'DJANGO_SETTINGS_MODULE=schedule_validation_settings', '--volume', f'{root.as_posix()}/schedule_validation_settings.py:/app/schedule_validation_settings.py:ro', 'beat', 'celery', '-A', 'sams', 'beat', '--loglevel=info', '--schedule=/tmp/validation-schedule-2', '--max-interval=2']
start = datetime.now(timezone.utc).isoformat()
subprocess.run(command, cwd=root / 'SAMS', check=True, timeout=60)
deadline = time.monotonic() + 60
logs = ''
try:
    while time.monotonic() < deadline:
        result = subprocess.run([docker, 'logs', name], capture_output=True, text=True, timeout=15)
        logs = result.stdout + result.stderr
        if 'Sending due task' in logs:
            break
        time.sleep(1)
finally:
    subprocess.run([docker, 'stop', name], check=True, timeout=45)
    result = subprocess.run([docker, 'logs', name], capture_output=True, text=True, timeout=15)
    logs = result.stdout + result.stderr
    (out / 'accelerated-beat-verified.txt').write_text('Started: ' + start + '\n' + logs, encoding='utf-8')
print('Scheduler dispatch observed:', 'Sending due task' in logs)
