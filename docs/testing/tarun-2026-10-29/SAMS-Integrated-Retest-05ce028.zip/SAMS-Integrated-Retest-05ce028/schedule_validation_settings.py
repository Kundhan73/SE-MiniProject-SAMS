"""Temporary local scheduler validation; imported only by the test beat container."""
from sams.settings import *  # noqa: F403

CELERY_BEAT_SCHEDULE = {
    'validation-nightly-attendance-10s': {
        'task': 'notifications.tasks.nightly_scan',
        'schedule': 10.0,
    },
}
